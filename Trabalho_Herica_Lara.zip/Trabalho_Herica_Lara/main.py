#1° parte 

import csv
contador=0
dataset ='artistas.csv'
dados=[]


with open(dataset, 'r', encoding='utf-8') as arquivo:
    leitor = csv.DictReader(arquivo)
    for registro in leitor:
        dados.append(registro)

for i in range(min(5, len(dados))):
        print(f"{i+1}: {dados[i]}")
    
'''  
1 - Anotações: 
- len(dados) → medindo a quantidade total de registros
min(5, len(dados)) → pega: 5 (se tiver muitos dados) ou menos (se o arquivo for pequeno)
i vai ser: 0, 1, 2, 3, 4

#2  i+1 → só para começar a contagem em 1
dados[i] → acessa cada registro
'''

#2° parte
import csv

dataset = "artistas.csv"
dados = []

# Lendo o arquivo
with open(dataset, 'r', encoding='utf-8') as arquivo:
    leitor = csv.DictReader(arquivo)
    for registro in leitor:
        dados.append(registro)

colunas = ['monthly_listeners_millions_mar2026', 'followers_millions']

def calcular_estatisticas(lista_valores):
    if len(lista_valores) == 0:
        return None, None, None, 0
    
    minimo = min(lista_valores)
    maximo = max(lista_valores)
    media = sum(lista_valores) / len(lista_valores)
    contagem = len(lista_valores)
    
    return minimo, maximo, media,contagem

# Processando cada coluna
for coluna in colunas:
    valores = []
    
    for registro in dados:
        valor = registro.get(coluna, '').strip()
        
        # Verifica se é válido
        if valor != '':
            valores.append(float(valor))
        else:
            continue  # ignora valores inválidos
    
    minimo, maximo, media, contagem = calcular_estatisticas(valores)
    
    # Exibindo resultados
    print(f"\n Estatísticas da coluna: {coluna}")
    print(f"Quantidade de valores válidos: {contagem}")
    
    if contagem > 0:
        print(f"Valor mínimo: {minimo}")
        print(f"Valor máximo: {maximo}")
        print(f"Média: {media:.2f}")
    else:
        print("Nenhum valor válido encontrado.")

# 3° parte : Consiste na abordagem feita por filtros
#filtros escolhidos: genero, estilo ano de debut do artista e quantidade de seguidores
#Filtro Genre 

usuario = input("Digite o genero do artista:\n •Male para homem\n •Female para mulher\n")

#Filtro gender 

if usuario=='Female':
    filtered_by_gender = []
    for linha in dados:
        if linha['gender'] == 'Female':
            filtered_by_gender.append(linha)
            print(filtered_by_gender)

elif usuario == 'Male':
    filtered_by_gender = []
    for linha in dados:
        if linha['gender'] == 'Male':
            filtered_by_gender.append(linha)
            print(filtered_by_gender)
else: 
    print('Artista não encontrado. \n Digite novamente:')
    
#Filtro followers millions

filtered_by_followers_millions = []
for linha in dados:
    if linha['followers_millions'] >= '110':
        filtered_by_followers_millions.append(linha)
        print(filtered_by_followers_millions)


#Fitro debut year

usuario=input("Digite um ano aleatorio e descubra quem debutou nele:")

filtered_by_debut_year = []
for linha in dados:
    if usuario >= '2014':
        filtered_by_debut_year.append(linha)
        print(filtered_by_debut_year)     
    elif usuario <= '2013':
        filtered_by_debut_year.append(linha)
        print(filtered_by_debut_year)  
    else:
        print('Valor não encontrado')   


#Parte 4:
with open ('relatorio.txt', 'w', encoding='utf-8') as arquivo:
    arquivo.write('Nome do dataset: artistas.csv\n')
    arquivo.write('Descrição: O dataset apresenta uma lista dos 50 artistas mais escutados mais escutados no ano de 2025.\n\n')

    total_registros = len(dados)
    total_colunas = len(dados[0]) if dados else 0

    arquivo.write(f"Quantidade total de registros: {total_registros}\n")
    arquivo.write(f"Quantidade total de colunas: {total_colunas}\n\n")

    # Parte das estatísticas 
    
    arquivo.write('Estatísticas calculadas:\n')

    for coluna in colunas:
        valores = []

        for registro in dados:
            valor = registro.get(coluna, '').strip()
            if valor != '':
                valores.append(float(valor))

        minimo, maximo, media, contagem = calcular_estatisticas(valores)

        arquivo.write(f"\nColuna: {coluna}\n")
        arquivo.write(f"Quantidade de valores válidos: {contagem}\n")

        if contagem > 0:
            arquivo.write(f"Valor mínimo: {minimo}\n")
            arquivo.write(f"Valor máximo: {maximo}\n")
            arquivo.write(f"Média: {media:.2f}\n")

    # Parte dos filtros no relatório
    arquivo.write("\nResultado dos filtros:\n")
    females = [dado for dado in dados if dado['gender'] == 'Female']
    males = [dado for dado in dados if dado['gender'] == 'Male']

    arquivo.write(f"Quantidade de artistas femininas: {len(females)}\n")
    arquivo.write(f"Quantidade de artistas masculinos: {len(males)}\n")

    populares = [dado for dado in dados if dado['followers_millions'] != '' and float(dado['followers_millions']) >= 100]
    arquivo.write(f"Artistas com mais de 100M seguidores: {len(populares)}\n")

    recentes = [dado for dado in dados if dado['debut_year'] != '' and int(dado['debut_year']) >= 2000]
    arquivo.write(f"Artistas que debutaram após 2000: {len(recentes)}\n")
        
    # Conclusão:
    arquivo.write("\nConclusão:\n")
    arquivo.write("1. Quanto mais próximo dos primeiros lugares é possível notar mais homens ocupando esses espaços.\n")
    arquivo.write("2. A maioria dos artistas debutaram do ano 2000 para frente.\n")
    arquivo.write("3. Os estilos musicais predominantes são pop e hip-hop/rap.\n")
    arquivo.write("4. O país referente aos artistas que mais aparece é o Estados Unidos.\n")